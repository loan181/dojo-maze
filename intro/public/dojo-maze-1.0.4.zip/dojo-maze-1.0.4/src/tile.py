
class TILE:
    free 	= " "
    wall 	= "X"
    player 	= "J"
    goal 	= "G"