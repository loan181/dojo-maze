# dojo-maze
Projet de labyrinthe pour coder dojo

## Execution
```sh
python3 main.py
```